# CodeAlpha_HangmanGame

**CodeAlpha Python Programming Internship - Task 1**

A simple text-based Hangman game played in the console.

## Features
- 5 predefined words (no file or API needed)
- Maximum of **6 incorrect guesses**
- Input validation (single letters only, repeated guesses are ignored)
- Play-again option
- Console input/output only (no graphics or audio)

## Concepts Used
`random`, `while` loop, `if-else`, strings, lists

## How to Run
```bash
python hangman.py
```

## Sample Output
```
Word: _ _ _ _ _ _
Wrong guesses left: 6
Guessed so far: -
Enter a letter: p
Good guess!
```

## Requirements
- Python 3.8+ (no external libraries needed)

## Author
Python Programming Intern - [CodeAlpha](https://www.codealpha.tech)

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file.
